﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class puzzleGUI : MonoBehaviour {
	// const int BOARD_ORIGIN_X = 427;
	// const int BOARD_ORIGIN_Y = 310;
	const int BOARD_ORIGIN_X = -127;
	const int BOARD_ORIGIN_Y = 107;
	UnityEngine.UI.Button prevButton;
	UnityEngine.UI.Button resetButton;
	UnityEngine.UI.Button nextButton;
	UnityEngine.UI.Button exitButton;

	void Start () {
	}
	
	public void PreviousPuzzleButtonClick() {
		// Change which puzzle we look at if we're not at the end of the list
		Debug.Log("You pressed the 'Previous' button.");
	}

	public void ResetPuzzleButtonClick() {
		// Re-instantiate the puzzle from the ASCII board read from STDIN
		Debug.Log("You pressed the 'Reset' button.");
	}

	public void NextPuzzleButtonClick() {
		// Go to the next puzzle in the list; Limit of 10? It must have a good range of # of pegs
		Debug.Log("You pressed the 'Next' button.");
	}

	public void ExitPuzzleButtonClick() {
		// if (puzzleCanvas.enabled) {
		// 	foreach (GameObject peg in pegs) {
		// 		GameObject.Destroy(peg);
		// 		pegs.Remove(peg);
		// 		// peg.SetActive(false);
		// 	}
		// 	// Disable Puzzle Canvas
		// 	puzzleCanvas.enabled = false;
		// }
	}

	public void FirstPuzzle() {
		// for (int i = 0; i < 100; i += 25) {
		// 	Transform tempPeg = GameObject.Instantiate(pegSprite, new Vector3(BOARD_ORIGIN_X, BOARD_ORIGIN_Y - i, 0), Quaternion.identity);
		// 	// GameObject tempPeg = GameObject.Instantiate(GameObject.Find(pegSprite.name), new Vector3(BOARD_ORIGIN_X, BOARD_ORIGIN_Y - i, 0), Quaternion.identity);
		// 	tempPeg.transform.SetParent(GameObject.Find("PuzzlePanel").transform, false);
		// }
		// GameObject tempObject = UnityEngine.Object.Instantiate(UnityEngine.GameObject.Find("PegSprite"), baseTransform);
		// tempObject.name = "PegSprite1";
		// pegs.Add(tempObject);
		
		// ((RectTransform) baseTransform).position = new Vector3(-15.0f, 120.0f, 0.0f);
		// tempObject = UnityEngine.Object.Instantiate(UnityEngine.GameObject.Find("PegSprite"), baseTransform);
		// tempObject.name = "PegSprite2";
		// pegs.Add(UnityEngine.Object.Instantiate(UnityEngine.GameObject.Find("PegSprite"), baseTransform));
		
		// ((RectTransform) baseTransform).position = new Vector3(-45.0f, 116.9f, 0.0f);
		// tempObject = UnityEngine.Object.Instantiate(UnityEngine.GameObject.Find("PegSprite"), baseTransform);
		// tempObject.name = "PegSprite3";
		// pegs.Add(UnityEngine.Object.Instantiate(UnityEngine.GameObject.Find("PegSprite"), baseTransform));


		// foreach (Vector2 v in basePeg.vertices) {
		// 	Debug.Log(v + "\n");
		// }
		// pegs.Add(UnityEngine.Object.Instantiate(UnityEngine.GameObject.Find("PegSprite"), Vector3.left, Quaternion.identity));
	}

	// Update is called once per frame
	void Update () {
		// Enable the pegs if necessary
		// if (puzzleCanvas.enabled) {
			// UnityEngine.GameObject.Destroy(testPeg);
			// pegRenderer.enabled = true;
			// foreach (GameObject peg in pegs) {
			// 	peg.SetActive(true);
			// 
		// }
	}


}
